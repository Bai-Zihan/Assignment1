/**
 * File Name: index.js（routes）
 * Student's Name: Wenshuo Li
 * StudentID: [2023111040]
 * Date: [2025-11-17]
 */

const express = require('express');
const router = express.Router();

router.get('/', (req, res) => {
  res.render('index', { 
    title: 'Home', 
    page: 'home'
  });
});

router.get('/about', (req, res) => {
  res.render('about', { 
    title: 'About Me', 
    page: 'about',
    studentName: 'Wenshuo Li', 
    studentAge: '20 years old'
  });
});

router.get('/projects', (req, res) => {
  const projects = [
    {
      title: 'GUI Application and Files',
      img: '/images/project1.png',
      desc: 'A desktop application with an intuitive graphical user interface for managing files and documents efficiently.'
    },
    {
      title: 'Used Acquisition Platform Project',
      img: '/images/project2.png',
      desc: 'A web-based platform for buying and selling used items with secure transaction features and user verification.'
    },
    {
      title: 'Course Registration System for Students',
      img: '/images/project3.png',
      desc: 'A student-focused system for managing course registrations, class schedules, and academic records.'
    }
  ];

  res.render('projects', { 
    title: 'Projects', 
    page: 'projects',
    projects: projects 
  });
});

router.get('/services', (req, res) => {
  const services = [
    {
      title: 'General Programming',
      img: '/images/service1.png',
      icon: 'fa-code',
      desc: 'Custom programming solutions using C# and other languages. From algorithm implementation to desktop applications, I can develop efficient and reliable software tailored to your needs.'
    },
    {
      title: 'Web Development',
      img: '/images/service2.png',
      icon: 'fa-globe',
      desc: 'Responsive website development using HTML, CSS, and related technologies. I create user-friendly web interfaces and functional web applications for various purposes.'
    },
    {
      title: 'Mobile Apps',
      img: '/images/service3.png',
      icon: 'fa-mobile',
      desc: 'Mobile application development with a focus on intuitive design and performance. I build apps that provide great user experiences across different mobile platforms.'
    }
  ];

  res.render('services', { 
    title: 'Services', 
    page: 'services',
    services: services 
  });
});

router.get('/contact', (req, res) => {
  res.render('contact', { 
    title: 'Contact Me', 
    page: 'contact',
    contactInfo: { 
      email: 'wenshuo.li@example.com',
      phone: '+86 123 4567 8910',
      location: 'Suzhou, Jiangsu, China'
    }
  });
});

router.post('/contact', (req, res) => {
  const formData = {
    firstName: req.body.firstName,
    lastName: req.body.lastName,
    contactNumber: req.body.contactNumber,
    email: req.body.email,
    message: req.body.message
  };

  console.log('Contact Form Submission:', formData);

  res.redirect('/');
});

module.exports = router;