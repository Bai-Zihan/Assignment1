/*
File Name: script（public/js）
Student's Name: Wenshuo Li
StudentID: [2023111040]
Date: [2025-11-17]
*/

//1. Mobile menu toggle function
const menuBtn = document.getElementById('menuBtn');
const mobileMenu = document.getElementById('mobileMenu');

if (menuBtn && mobileMenu) {
  menuBtn.addEventListener('click', () => {
    mobileMenu.classList.toggle('hidden');
    
    const icon = menuBtn.querySelector('i');
    if (mobileMenu.classList.contains('hidden')) {
      icon.classList.remove('fa-times');
      icon.classList.add('fa-bars');
    } else {
      icon.classList.remove('fa-bars');
      icon.classList.add('fa-times');
    }
  });
}

// 2. Navigation bar scrolling effect
const navbar = document.getElementById('navbar');

if (navbar) {
  window.addEventListener('scroll', () => {
    if (window.scrollY > 10) {
      navbar.classList.add('shadow-lg');
      navbar.classList.add('bg-primary/95');
      navbar.classList.add('backdrop-blur-sm');
    } else {
      navbar.classList.remove('shadow-lg');
      navbar.classList.remove('bg-primary/95');
      navbar.classList.remove('backdrop-blur-sm');
    }
  });
}

// 3. Form Validation (Contact Page)
const contactForm = document.getElementById('contactForm');

if (contactForm) {
  const nameError = document.getElementById('nameError');
  const emailError = document.getElementById('emailError');
  const contactError = document.getElementById('contactError');
  const messageError = document.getElementById('messageError');
  const submitBtn = document.getElementById('submitBtn');

  contactForm.addEventListener('submit', function(e) {
    let isValid = true;
    nameError.classList.add('hidden');
    emailError.classList.add('hidden');
    contactError.classList.add('hidden');
    messageError.classList.add('hidden');

    const firstName = document.getElementById('firstName').value.trim();
    const lastName = document.getElementById('lastName').value.trim();
    const contactNumber = document.getElementById('contactNumber').value.trim();
    const email = document.getElementById('email').value.trim();
    const message = document.getElementById('message').value.trim();

    // 3. Verification logic
    if (!firstName || !lastName) {
      nameError.textContent = 'Please enter your full name';
      nameError.classList.remove('hidden');
      isValid = false;
    }

    if (!contactNumber) {
      contactError.textContent = 'Please enter your contact number';
      contactError.classList.remove('hidden');
      isValid = false;
    }

    const emailRegex = /^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$/i;
    if (!emailRegex.test(email)) {
      emailError.textContent = 'Please enter a valid email address';
      emailError.classList.remove('hidden');
      isValid = false;
    }

    if (message.length < 10) {
      messageError.textContent = 'Message must be at least 10 characters';
      messageError.classList.remove('hidden');
      isValid = false;
    }

    if (!isValid) {
      e.preventDefault();
    } else {
      submitBtn.disabled = true;
      submitBtn.innerHTML = '<i class="fa fa-spinner fa-spin mr-2"></i> Sending...';
    }
  });
}