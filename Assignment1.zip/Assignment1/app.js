/*
File Name: app.js
Student's Name: Wenshuo Li
StudentID: [2023111040]
Date: [2025-11-17]
*/

const express = require('express');
const path = require('path');
const bodyParser = require('body-parser'); 
const indexRouter = require('./routes/index');

const app = express();

app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');                
app.set('view cache', process.env.NODE_ENV === 'production'); 

app.use(bodyParser.urlencoded({ extended: false })); 
app.use(express.static(path.join(__dirname, 'public'))); 

app.use('/', indexRouter);

app.use((req, res, next) => {
  const err = new Error('Page Not Found');
  err.status = 404;
  next(err);
});

app.use((err, req, res, next) => {
  res.status(err.status || 500);
  res.render('error', { 
    message: err.message,
    error: req.app.get('env') === 'development' ? err : {}
  });
});

module.exports = app;